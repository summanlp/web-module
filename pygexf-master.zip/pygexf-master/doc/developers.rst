
welcome developers
------------------

versioning system used is git, hosted in github : http://github.com/paul.girard/pygexf

documentation is on the way...

